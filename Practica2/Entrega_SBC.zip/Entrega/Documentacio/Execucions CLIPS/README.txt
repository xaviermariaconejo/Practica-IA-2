En aquesta carpeta es poden consultar les diverses execucions de CLIPS per als jocs de proves 

Els noms dels fitxers corresponen a cadascun dels jocs de proves disponibles a la secció 3 de la documentació del projecte.

NOTA: Per tal de facilitar la lectura dels outputs, hem arreglat alguns dels caràcters accentuats que CLIPS genera malament per no treballar en UTF-8.
