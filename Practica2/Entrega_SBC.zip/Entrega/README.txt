Aquesta és l'entrega de la segona pràctica de l'assignatura: Intel·ligència artificial

Autors:

  Luis Delicado Alcántara
  Xavier Conejo Micó
  Josep Sánchez Ferreres
  
En aquesta carpeta s'hi poden trobar 3 subdirectoris:

Documentació: Conté la documentació de la pràctica

CLIPS: Conté tot el codi font de la pràctica en CLIPS.

Ontologia: Conté l'ontologia de la pràctica en format del programa Protégé